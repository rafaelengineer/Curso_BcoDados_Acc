var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database: "db_atividade4_p2"
});

con.connect(function(err) {
  if (err) throw err;
  var sql = "DROP TABLE Historico";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table deleted");
  var sql = "DROP TABLE Turma";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table deleted");
  var sql = "DROP TABLE Alunos";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table deleted");
  });
  var sql = "DROP TABLE Disciplinas ";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table deleted");
  });
  var sql = "DROP TABLE Professores";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table deleted");
  });
  });
  });
});