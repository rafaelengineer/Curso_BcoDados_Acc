var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database: "db_atividade4_p2"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  //Make SQL statement:
  
  //var sql = "INSERT INTO db_atividade4_p2.Alunos (MAT, nome, endereco, cidade) VALUES ?";
  var sql = "INSERT INTO db_atividade4_p2.Alunos (MAT, nome, endereco, cidade) VALUES ?";
  //Make an array of values:
  var values = [
    [2015010101, 'JOSE DE ALENCAR', 'RUA DAS ALMAS', 'NATAL'],
    [2015010102, 'JOÃO JOSÉ', 'AVENIDA RUY CARNEIRO', 'JOÃO PESSOA'],
    [2015010103, 'MARIA JOAQUINA', 'RUA CARROSSEL', 'RECIFE'],
    [2015010104, 'MARIA DAS DORES', 'RUA DAS LADEIRAS', 'FORTALEZA'],
    [2015010105, 'JOSUÉ CLAUDINO DOS SANTOS', 'CENTRO', 'NATAL'],
    [2015010106, 'JOSUÉLISSON CLAUDINO DOS SANTOS', 'CENTRO', 'NATAL']
  ];
  //Execute the SQL statement, with the value array:
  con.query(sql, [values], function (err, result) {
    if (err) throw err;
    console.log("Number of records inserted: " + result.affectedRows);
  });

  //var sql = "INSERT INTO db_atividade4_p2.Disciplinas (COD_DISC, nome_disc, carga_hor) VALUES ?";
  var sql = "INSERT INTO db_atividade4_p2.Disciplinas (COD_DISC, nome_disc, carga_hor) VALUES ?";
  //Make an array of values:
  var values = [
    ['BD', 'BANCO DE DADOS', 100],
    ['POO', 'PROGRAMAÇÃO COM ACESSO A BANCO DE DADOS', 100],
    ['WEB', 'AUTORIA WEB', 50],
    ['ENG', 'ENGENHARIA DE SOFTWARE', 80]
  ];
  //Execute the SQL statement, with the value array:
  con.query(sql, [values], function (err, result) {
    if (err) throw err;
    console.log("Number of records inserted: " + result.affectedRows);
  });
  //var sql = "INSERT INTO db_atividade4_p2.Professores  (COD_PROF, nome, endereco, cidade) VALUES ?";
  var sql = "INSERT INTO db_atividade4_p2.Professores  (COD_PROF, nome, endereco, cidade) VALUES ?";
  //Make an array of values:
  var values = [
    [212131, 'NICKERSON FERREIRA', 'RUA MANAÍRA', 'JOÃO PESSOA'],
    [122135, 'ADORILSON BEZERRA', 'AVENIDA SALGADO FILHO', 'NATAL'],
    [192011, 'DIEGO OLIVEIRA', 'AVENIDA ROBERTO FREIRE', 'NATAL']
  ];
  //Execute the SQL statement, with the value array:
  con.query(sql, [values], function (err, result) {
    if (err) throw err;
    console.log("Number of records inserted: " + result.affectedRows);
  });
  //var sql = "INSERT INTO db_atividade4_p2.Turma (COD_DISC, COD_TURMA, COD_PROF, ANO, horario) VALUES ?";
  var sql = "INSERT INTO db_atividade4_p2.Turma (COD_DISC, COD_TURMA, COD_PROF, ANO, horario) VALUES ?";
  //Make an array of values:
  var values = [
    ['BD', 1, 212131, 2015, '11H-12H'],
    ['BD', 2, 212131, 2015, '13H-14H'],
    ['POO', 3, 192011, 2015, '08H-09H'],
    ['WEB', 4, 192011, 2015, '07H-08H'],
    ['ENG', 5, 122135, 2015, '10H-11H']
  ];
  //Execute the SQL statement, with the value array:
  con.query(sql, [values], function (err, result) {
    if (err) throw err;
    console.log("Number of records inserted: " + result.affectedRows);
  });
  //var sql = "INSERT INTO db_atividade4_p2.Historico (MAT, COD_DISC, COD_TURMA, COD_PROF, ANO, frequência, nota) VALUES ?";
  var sql = "INSERT INTO db_atividade4_p2.Historico (MAT, COD_DISC, COD_TURMA, COD_PROF, ANO, frequência, nota) VALUES ?";
  //Make an array of values:
  var values = [
    [2015010101, 'BD', 1, 212131, 2015, 75, 8.5],
    [2015010101, 'BD', 2, 212131, 2015, 90, 9.2],
    [2015010101, 'POO', 1, 192011, 2015, 80, 8.0],
    [2015010101, 'POO', 3, 192011, 2015, 65, 7.3],
    [2015010101, 'WEB', 3, 192011, 2015, 95, 9.7],
    [2015010101, 'WEB', 2, 192011, 2015, 70, 7.8],
    [2015010101, 'ENG', 1, 122135, 2015, 88, 8.8],
    [2015010101, 'ENG', 2, 122135, 2015, 75, 7.5],
    [2015010102, 'BD', 1, 212131, 2015, 78, 8.2],
    [2015010102, 'BD',  4, 212131, 2015, 92, 9.0],
    [2015010102, 'POO', 4,  192011, 2015, 85, 8.5],
    [2015010102, 'POO', 2, 192011, 2015, 68, 7.0],
    [2015010102, 'WEB', 1, 192011, 2015, 94, 9.3],
    [2015010102, 'WEB', 5, 192011, 2015, 73, 7.3],
    [2015010102, 'ENG', 5, 122135, 2015, 90, 9.0],
    [2015010102, 'ENG', 2, 122135, 2015, 77, 7.7],
    [2015010103, 'BD', 1, 212131, 2015, 80, 8.0],
    [2015010103, 'BD', 2, 212131, 2015, 89, 9.0],
    [2015010103, 'POO', 1, 192011, 2015, 87, 8.5],
    [2015010103, 'POO', 5, 192011, 2015, 70, 7.2],
    [2015010103, 'WEB', 5, 192011, 2015, 92, 9.3],
    [2015010103, 'WEB', 4, 192011, 2015, 75, 7.5],
    [2015010103, 'ENG', 4, 122135, 2015, 89, 8.9],
    [2015010103, 'ENG', 2, 122135, 2015, 72, 7.2],
    [2015010104, 'BD', 1, 212131, 2015, 75, 7.5],
    [2015010104, 'BD', 2, 212131, 2015, 91, 9.1],
    [2015010104, 'POO', 1, 192011, 2015, 84, 8.4],
    [2015010104, 'POO', 3, 192011, 2015, 67, 6.7],
    [2015010104, 'WEB', 3, 192011, 2015, 91, 9.1],
    [2015010104, 'WEB', 2, 192011, 2015, 74, 7.4],
    [2015010104, 'ENG', 1, 122135, 2015, 87, 8.7],
    [2015010104, 'ENG',3,  122135, 2015, 71, 7.1],
    [2015010105, 'BD', 3, 212131, 2015, 80, 8.0],
    [2015010105, 'BD', 2, 212131, 2015, 89, 9.0],
    [2015010105, 'POO', 1, 192011, 2015, 87, 8.5],
    [2015010105, 'POO', 2, 192011, 2015, 70, 7.2],
    [2015010105, 'WEB', 5, 192011, 2015, 92, 9.3],
    [2015010105, 'WEB', 5, 192011, 2015, 75, 7.5],
    [2015010105, 'ENG', 4, 122135, 2015, 89, 8.9],
    [2015010105, 'ENG', 4, 122135, 2015, 72, 7.2]
  ];
  //Execute the SQL statement, with the value array:
  con.query(sql, [values], function (err, result) {
    if (err) throw err;
    console.log("Number of records inserted: " + result.affectedRows);
  });
  con.end();
});