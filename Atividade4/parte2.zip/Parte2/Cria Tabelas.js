//Necessário ser criado previamente o Schema atividade4 no MySql
//No Arquivo config.js, nome do Schema: db_atividade4_p2

const Sequelize = require("sequelize");
const sequelize = require("./config");

const Alunos = sequelize.define("Alunos", {
  MAT: {
    type: Sequelize.INTEGER,
    primaryKey: true,
  },
  nome: {
    type: Sequelize.STRING,
  },
  endereco: {
    type: Sequelize.STRING,
  },
  cidade: {
    type: Sequelize.STRING,
  },
}, {
  timestamps: false,
  tableName: "Alunos"
});

const Disciplinas = sequelize.define("Disciplinas", {
  COD_DISC: {
    type: Sequelize.STRING,
    primaryKey: true,
  },
  nome_disc: {
    type: Sequelize.STRING,
  },
  carga_hor: {
    type: Sequelize.INTEGER,
  },
}, {
  timestamps: false,
  tableName: "Disciplinas"
});

const Professores = sequelize.define("Professores", {
  COD_PROF: {
    type: Sequelize.INTEGER,
    primaryKey: true,
  },
  nome: {
    type: Sequelize.STRING,
  },
  endereco: {
    type: Sequelize.STRING,
  },
  cidade: {
    type: Sequelize.STRING,
  },
}, {
  timestamps: false,
  tableName: "Professores"
});

const Turma = sequelize.define("Turma", {
  COD_DISC: {
    type: Sequelize.STRING,
  },
  COD_TURMA: {
    type: Sequelize.INTEGER,
    primaryKey: true,
  },
  COD_PROF: {
    type: Sequelize.INTEGER,
  },
  ANO: {
    type: Sequelize.INTEGER,
  },
  horario: {
    type: Sequelize.STRING,
  },
}, {
  timestamps: false,
  tableName: "Turma"
});

const Historico = sequelize.define("Historico", {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  MAT: {
    type: Sequelize.INTEGER,
  },
  COD_DISC: {
    type: Sequelize.STRING,
  },
  COD_TURMA: {
    type: Sequelize.INTEGER,
  },
  COD_PROF: {
    type: Sequelize.INTEGER,
  },
  ANO: {
    type: Sequelize.INTEGER,
  },
  frequência: {
    type: Sequelize.INTEGER,
  },
  nota: {
    type: Sequelize.FLOAT,
  },
}, {
  timestamps: false,
  tableName: "Historico"
});

Alunos.belongsTo(Disciplinas, {
  foreignKey: "COD_DISC",
});

Alunos.belongsTo(Professores, {
  foreignKey: "COD_PROF",
});

Turma.belongsTo(Disciplinas, {
  foreignKey: "COD_DISC",
});

Turma.belongsTo(Professores, {
  foreignKey: "COD_PROF",
});

Historico.belongsTo(Alunos, {
  foreignKey: "MAT",
});

Historico.belongsTo(Turma, {
  foreignKey: ["COD_DISC", "COD_TURMA", "COD_PROF", "ANO"],
});


sequelize.sync().then(() => {
  console.log("Modelo sincronizado com o banco de dados");
}).catch((err) => {
  console.error("Erro na sincronização com o banco de dados:", err);
});