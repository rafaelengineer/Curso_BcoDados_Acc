//Necessário ser criado previamente o Schema atividade4 no MySql
//No Arquivo config.js, nome do Schema: db_atividade4

const Sequelize = require("sequelize");
const sequelize = require("./config");

const Produto = sequelize.define("Produto", {
  id_nf: {
    type: Sequelize.INTEGER,
  },
  id_item: {
    type: Sequelize.INTEGER,
  },
  cod_pro: {
    type: Sequelize.INTEGER,
  },
  valor_unit: {
    type: Sequelize.FLOAT,
  },
  quantidade: {
    type: Sequelize.INTEGER,
  },
  desconto: {
    type: Sequelize.INTEGER,
  },
}, {
  timestamps: false,
  tableName: "Produtos"
});


sequelize.sync().then(() => {
  console.log("Modelo sincronizado com o banco de dados");
}).catch((err) => {
  console.error("Erro na sincronização com o banco de dados:", err);
});